#!/usr/bin/env python3
"""
RSS自动抓取引擎 v1.8

修复:
- 修复 get_free_space 调用
- 改进RSS解析和错误处理
"""

import os
import re
import time
import json
import hashlib
import threading
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import OrderedDict

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False

try:
    import feedparser
    FEEDPARSER_AVAILABLE = True
except ImportError:
    FEEDPARSER_AVAILABLE = False


@dataclass
class RSSItem:
    title: str
    link: str
    torrent_url: str
    size: int = 0
    pub_date: Optional[datetime] = None
    info_hash: str = ""
    site_id: int = 0
    site_name: str = ""


@dataclass
class FetchResult:
    site_id: int
    site_name: str
    success: bool
    items_found: int = 0
    items_added: int = 0
    items_skipped: int = 0
    error: str = ""
    timestamp: float = field(default_factory=time.time)


class LRUCache:
    def __init__(self, capacity: int = 10000):
        self.cache: OrderedDict = OrderedDict()
        self.capacity = capacity
        self._lock = threading.Lock()
    
    def get(self, key: str) -> bool:
        with self._lock:
            if key in self.cache:
                self.cache.move_to_end(key)
                return True
            return False
    
    def put(self, key: str):
        with self._lock:
            if key in self.cache:
                self.cache.move_to_end(key)
            else:
                if len(self.cache) >= self.capacity:
                    self.cache.popitem(last=False)
                self.cache[key] = True
    
    def clear(self):
        with self._lock:
            self.cache.clear()
    
    def size(self) -> int:
        with self._lock:
            return len(self.cache)
    
    def to_list(self) -> List[str]:
        with self._lock:
            return list(self.cache.keys())
    
    def load_from_list(self, items: List[str]):
        with self._lock:
            self.cache.clear()
            for item in items[-self.capacity:]:
                self.cache[item] = True


class RSSEngine:
    def __init__(self, db, qb_manager, notifier=None, logger=None):
        self.db = db
        self.qb_manager = qb_manager
        self.notifier = notifier
        self.logger = logger or logging.getLogger("rss_engine")
        
        self._running = False
        self._thread = None
        self._stop_event = threading.Event()
        
        self._fetch_interval = 300
        self._enabled = False
        self._min_free_space = 10 * 1024 * 1024 * 1024
        self._max_torrent_age = 24 * 3600  # 默认只抓取24小时内发布的种子
        self._max_items_per_fetch = 10  # 每次最多添加10个种子
        
        self._hash_cache = LRUCache(capacity=10000)
        self._last_fetch = {}
        self._fetch_results = []
        self._max_results = 100
        
        self._session = None
        if REQUESTS_AVAILABLE:
            self._session = requests.Session()
            self._session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
        
        self._load_cache()
    
    def _load_cache(self):
        try:
            cache_str = self.db.get_config('rss_hash_cache')
            if cache_str:
                cache_list = json.loads(cache_str)
                self._hash_cache.load_from_list(cache_list)
        except:
            pass
    
    def _save_cache(self):
        try:
            cache_list = self._hash_cache.to_list()
            self.db.set_config('rss_hash_cache', json.dumps(cache_list[-5000:]))
        except:
            pass
    
    def _log(self, level: str, message: str):
        getattr(self.logger, level.lower(), self.logger.info)(message)
        try:
            self.db.add_log(level.upper(), f"[RSS] {message}")
        except:
            pass
    
    def start(self):
        if self._running:
            return
        
        self._enabled = self.db.get_config('rss_fetch_enabled') == 'true'
        try:
            self._fetch_interval = int(self.db.get_config('rss_fetch_interval') or 300)
        except:
            self._fetch_interval = 300
        
        if not self._enabled:
            self._log('info', "RSS引擎已禁用")
            return
        
        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._worker, daemon=True, name="RSS-Engine")
        self._thread.start()
        self._log('info', f"RSS引擎已启动 (间隔: {self._fetch_interval}秒)")
    
    def stop(self):
        self._running = False
        self._stop_event.set()
        self._save_cache()
        self._log('info', "RSS引擎已停止")
    
    def enable(self):
        self._enabled = True
        self.db.set_config('rss_fetch_enabled', 'true')
        if not self._running:
            self.start()
    
    def disable(self):
        self._enabled = False
        self.db.set_config('rss_fetch_enabled', 'false')
    
    def set_interval(self, seconds: int):
        seconds = max(60, min(3600, seconds))
        self._fetch_interval = seconds
        self.db.set_config('rss_fetch_interval', str(seconds))
    
    def fetch_now(self, site_id: int = None) -> List[FetchResult]:
        return self._do_fetch(site_id)
    
    def clear_cache(self):
        self._hash_cache.clear()
        self.db.set_config('rss_hash_cache', '[]')
    
    def get_status(self) -> Dict[str, Any]:
        sites = self.db.get_pt_sites_with_rss()
        return {
            'enabled': self._enabled,
            'running': self._running,
            'fetch_interval': self._fetch_interval,
            'cache_size': self._hash_cache.size(),
            'sites_count': len(sites),
            'sites': [{'id': s['id'], 'name': s['name']} for s in sites],
            'last_fetch': self._last_fetch,
        }
    
    def get_results(self, limit: int = 50) -> List[Dict]:
        results = self._fetch_results[-limit:]
        return [{
            'site_id': r.site_id,
            'site_name': r.site_name,
            'success': r.success,
            'items_found': r.items_found,
            'items_added': r.items_added,
            'items_skipped': r.items_skipped,
            'error': r.error,
            'time': datetime.fromtimestamp(r.timestamp).strftime('%Y-%m-%d %H:%M:%S'),
            'time_str': datetime.fromtimestamp(r.timestamp).strftime('%H:%M:%S')
        } for r in reversed(results)]
    
    def _worker(self):
        while self._running and not self._stop_event.is_set():
            try:
                self._enabled = self.db.get_config('rss_fetch_enabled') == 'true'
                try:
                    self._fetch_interval = int(self.db.get_config('rss_fetch_interval') or 300)
                except:
                    pass
                
                if self._enabled:
                    self._do_fetch()
            except Exception as e:
                self._log('error', f"RSS抓取异常: {e}")
            
            self._stop_event.wait(self._fetch_interval)
    
    def _do_fetch(self, site_id: int = None) -> List[FetchResult]:
        results = []
        
        if not REQUESTS_AVAILABLE:
            return results
        
        sites = self.db.get_pt_sites_with_rss()
        
        if site_id:
            sites = [s for s in sites if s['id'] == site_id]
        
        for site in sites:
            result = self._fetch_site(site)
            results.append(result)
            self._fetch_results.append(result)
            
            if len(self._fetch_results) > self._max_results:
                self._fetch_results = self._fetch_results[-self._max_results:]
        
        self._save_cache()
        return results
    
    def _fetch_site(self, site: dict) -> FetchResult:
        site_id = site['id']
        site_name = site['name']
        rss_url = site.get('rss_url', '')
        cookie = site.get('cookie', '')
        
        result = FetchResult(site_id=site_id, site_name=site_name, success=False)
        
        if not rss_url:
            result.error = "未配置RSS URL"
            return result
        
        try:
            headers = {}
            if cookie:
                headers['Cookie'] = cookie
            
            self._log('info', f"[{site_name}] 开始抓取RSS...")
            
            resp = self._session.get(rss_url, headers=headers, timeout=30)
            resp.raise_for_status()
            
            items = self._parse_rss(resp.text, site)
            result.items_found = len(items)
            
            # 从数据库读取最大种子年龄配置（小时），默认24小时
            try:
                max_age_hours = int(self.db.get_config('rss_max_age_hours') or 24)
            except:
                max_age_hours = 24
            max_age_seconds = max_age_hours * 3600
            
            now = datetime.now()
            added = 0
            skipped = 0
            too_old = 0
            
            # items已按发布时间倒序排列（最新的在前）
            for item in items:
                # 检查种子年龄
                if item.pub_date:
                    age = (now - item.pub_date).total_seconds()
                    if age > max_age_seconds:
                        too_old += 1
                        continue  # 跳过太旧的种子
                
                # 检查是否已添加过
                hash_key = item.info_hash or hashlib.md5(item.torrent_url.encode()).hexdigest()
                if self._hash_cache.get(hash_key):
                    skipped += 1
                    continue
                
                # 限制每次添加数量
                if added >= self._max_items_per_fetch:
                    self._log('info', f"[{site_name}] 已达到单次添加上限 ({self._max_items_per_fetch})")
                    break
                
                # 选择实例并添加
                instance = self._select_best_instance(item.size)
                if not instance:
                    skipped += 1
                    continue
                
                if self._add_torrent(instance, item, cookie):
                    self._hash_cache.put(hash_key)
                    added += 1
                    age_str = ""
                    if item.pub_date:
                        age_minutes = int((now - item.pub_date).total_seconds() / 60)
                        if age_minutes < 60:
                            age_str = f" ({age_minutes}分钟前)"
                        else:
                            age_str = f" ({age_minutes // 60}小时前)"
                    self._log('info', f"[{site_name}] ✅ 添加: {item.title[:40]}{age_str}")
                else:
                    skipped += 1
            
            result.items_added = added
            result.items_skipped = skipped
            result.success = True
            self._last_fetch[site_id] = time.time()
            
            log_parts = [f"发现{len(items)}个"]
            if added > 0:
                log_parts.append(f"添加{added}个")
            if too_old > 0:
                log_parts.append(f"过旧{too_old}个")
            if skipped > 0:
                log_parts.append(f"跳过{skipped}个")
            self._log('info', f"[{site_name}] 完成: {', '.join(log_parts)}")
            
        except requests.exceptions.Timeout:
            result.error = "请求超时"
        except requests.exceptions.RequestException as e:
            result.error = f"请求失败: {str(e)[:50]}"
        except Exception as e:
            result.error = f"解析失败: {str(e)[:50]}"
            self._log('error', f"[{site_name}] 错误: {e}")
        
        return result
    
    def _parse_rss(self, content: str, site: dict) -> List[RSSItem]:
        items = []
        
        if FEEDPARSER_AVAILABLE:
            try:
                feed = feedparser.parse(content)
                for entry in feed.entries:
                    pub_date = None
                    if hasattr(entry, 'published_parsed') and entry.published_parsed:
                        try:
                            pub_date = datetime(*entry.published_parsed[:6])
                        except:
                            pass
                    
                    item = RSSItem(
                        title=entry.get('title', ''),
                        link=entry.get('link', ''),
                        torrent_url=self._extract_torrent_url(entry),
                        size=self._parse_size(entry),
                        pub_date=pub_date,
                        info_hash=self._extract_hash(entry),
                        site_id=site['id'],
                        site_name=site['name']
                    )
                    if item.torrent_url:
                        items.append(item)
                
                items.sort(key=lambda x: x.pub_date or datetime.min, reverse=True)
                return items
            except:
                pass
        
        # XML fallback
        try:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(content)
            for item in root.iter('item'):
                title = item.find('title')
                link = item.find('link')
                enclosure = item.find('enclosure')
                
                torrent_url = ''
                size = 0
                
                if enclosure is not None:
                    torrent_url = enclosure.get('url', '')
                    try:
                        size = int(enclosure.get('length', 0))
                    except:
                        pass
                elif link is not None:
                    torrent_url = link.text or ''
                
                if torrent_url:
                    items.append(RSSItem(
                        title=title.text if title is not None else '',
                        link=link.text if link is not None else '',
                        torrent_url=torrent_url,
                        size=size,
                        site_id=site['id'],
                        site_name=site['name']
                    ))
        except:
            pass
        
        return items
    
    def _extract_torrent_url(self, entry) -> str:
        for link in entry.get('links', []):
            if link.get('type') == 'application/x-bittorrent':
                return link.get('href', '')
            if 'torrent' in link.get('href', '').lower():
                return link.get('href', '')
        
        link = entry.get('link', '')
        if 'torrent' in link.lower() or link.endswith('.torrent'):
            return link
        
        for enc in entry.get('enclosures', []):
            url = enc.get('url', enc.get('href', ''))
            if url:
                return url
        
        return ''
    
    def _parse_size(self, entry) -> int:
        for enc in entry.get('enclosures', []):
            try:
                return int(enc.get('length', 0))
            except:
                pass
        return 0
    
    def _extract_hash(self, entry) -> str:
        link = entry.get('link', '')
        match = re.search(r'([a-fA-F0-9]{40})', link)
        if match:
            return match.group(1).lower()
        return ''
    
    def _select_best_instance(self, torrent_size: int) -> Optional[dict]:
        instances = self.db.get_qb_instances()
        candidates = []
        
        for inst in instances:
            if not inst.get('enabled'):
                continue
            
            inst_id = inst['id']
            if not self.qb_manager.is_connected(inst_id):
                continue
            
            free_space = self.qb_manager.get_free_space(inst_id)
            
            required = torrent_size + self._min_free_space
            if free_space >= required:
                candidates.append({
                    'instance': inst,
                    'free_space': free_space
                })
        
        if not candidates:
            return None
        
        candidates.sort(key=lambda x: x['free_space'], reverse=True)
        return candidates[0]['instance']
    
    def _add_torrent(self, instance: dict, item: RSSItem, cookie: str = '') -> bool:
        try:
            headers = {}
            if cookie:
                headers['Cookie'] = cookie
            
            resp = self._session.get(item.torrent_url, headers=headers, timeout=30)
            resp.raise_for_status()
            
            content_type = resp.headers.get('content-type', '')
            if 'html' in content_type.lower():
                return False
            
            success, msg = self.qb_manager.add_torrent(
                instance_id=instance['id'],
                torrent_file=resp.content
            )
            
            if success:
                try:
                    self.db.update_stats(total_added=1)
                except:
                    pass
            
            return success
            
        except:
            return False


def create_rss_engine(db, qb_manager, notifier=None) -> RSSEngine:
    logger = logging.getLogger("rss_engine")
    return RSSEngine(db, qb_manager, notifier, logger)
