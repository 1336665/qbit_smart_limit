# qBit Smart Web Manager v1.9

基于 `main.py v11.0.0 PRO` 智能限速脚本开发的Web管理平台。

## 🆕 v1.9 更新内容

### UI交互优化
- ✅ **全局Loading遮罩** - 长时间操作时显示进度条
- ✅ **按钮Loading状态** - 点击按钮后显示加载动画，防止重复点击
- ✅ **即时反馈** - 所有操作都有明确的进度提示
- ✅ **防重复提交** - 按钮在请求期间自动禁用

### 新功能
- 📤 **配置导出** - 一键导出所有配置为JSON文件
- 📥 **配置导入** - 从JSON文件恢复配置
- 🧪 **Telegram测试** - 一键测试Telegram通知
- ⚠️ **数据重置** - 一键重置所有数据（保留密码）

## 📦 核心功能

| 功能 | 说明 |
|------|------|
| 多qB实例管理 | 按剩余空间自动分配种子 |
| 智能限速 | PID/Kalman控制器，4阶段动态参数 |
| RSS自动抓取 | 定时抓取新种子，按发布时间排序 |
| 自动删种 | 8个内置规则，删前强制汇报 |
| 通用PT站点辅助器 | 支持所有NexusPHP站点 |
| 下载限速 + 汇报优化 | 防止超速，智能汇报时机 |
| Telegram通知 | 启动/添加/删除/警告 |
| 认证系统 | 首次设置密码，会话管理 |

## 🚀 快速开始

### 1. 解压
```bash
unzip qbit-smart-web-v1.9.zip
cd qbit-smart-web-v1.9
```

### 2. 安装依赖
```bash
pip install -r requirements.txt
```

### 3. 启动
```bash
python app.py
# 或使用启动脚本
chmod +x start.sh
./start.sh
```

### 4. 访问
打开浏览器访问 `http://你的IP:5000`，首次访问需要设置密码。

## ⚠️ 从旧版本升级

如果从v1.8或更早版本升级，建议删除旧数据库重新配置：
```bash
rm -f qbit_smart.db
python app.py
```

## 📋 内置删种规则

| 优先级 | 规则 | 条件 |
|--------|------|------|
| P100 | 🚨 紧急空间不足 | <5GB + <5MiB/s |
| P80 | ⚠️ 空间紧张 | <10GB + <1MiB/s |
| P60 | 📉 空间警告 | <20GB + 完成 + <512KiB/s |
| P40 | ⏰ 做种过长 | >7天 + 分享率>2 |
| P30 | 🐢 低速种子 | >3天 + <100KiB/s |
| P25 | 📦 超大种 | >100GB + >24h + 分享率>1 |
| P20 | 📈 高分享率 | >5.0 |
| P15 | ❄️ 冷门种子 | 无连接>6h + 完成 |

## 🔧 配置说明

### 汇报时间来源
每个站点可独立配置：

| 选项 | 需要Cookie | 说明 |
|------|-----------|------|
| 自动 | 可选 | 有Cookie用站点辅助，否则用qB API |
| 站点辅助器 | ✅ 必须 | 通过Peer List获取（最精确） |
| qB API | ❌ 不需要 | 通用方法（精度足够） |

### 热配置
所有Web上的修改都是热配置，**无需重启**：
- 添加/删除站点 → 下一轮（≤5秒）自动识别
- 修改限速规则 → 下一轮生效
- 启用/禁用功能 → 立即生效

## 📁 项目结构

```
qbit-smart-web-v1.9/
├── app.py                    # Flask主入口
├── database.py               # 数据库模块
├── qb_manager.py             # qB管理器
├── pt_site_helper.py         # 通用PT站点辅助器
├── precision_limit_engine.py # 精准限速引擎
├── rss_engine.py             # RSS抓取引擎
├── auto_remove_engine.py     # 自动删种引擎
├── notifier.py               # 通知模块
├── templates/
│   ├── index.html            # 主页面
│   ├── login.html            # 登录页
│   └── setup.html            # 初始设置页
├── requirements.txt          # Python依赖
├── start.sh                  # 启动脚本
└── Dockerfile                # Docker支持
```

## 🐳 Docker部署

```bash
docker build -t qbit-smart-web .
docker run -d -p 5000:5000 -v $(pwd)/data:/app/data qbit-smart-web
```

## 📜 更新日志

### v1.9.0 (2026-01-05)
- 添加全局Loading遮罩和进度条
- 添加按钮Loading状态防止重复点击
- 添加配置导出/导入功能
- 添加Telegram测试功能
- 添加数据重置功能
- 优化所有API调用的反馈提示

### v1.8.0
- 全面修复前后端参数不匹配问题
- 修复汇报API参数
- 修复删除种子确认框

### v1.7.0
- 完善自动删种引擎
- RSS按发布时间排序
- 添加删种日志

## 📝 许可证

MIT License
